
//these are all the functions from syntax.c that can be utilzed by other c files
int isValidCommand(char *token);
int isValidExpression(char *expression);
